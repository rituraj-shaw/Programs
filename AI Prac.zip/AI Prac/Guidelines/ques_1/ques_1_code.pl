% Define the sum predicate to calculate the sum of two numbers
sum(X, Y, Z) :-
    Z is X + Y.
