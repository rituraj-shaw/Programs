palindrome(L) :-
    reverse(L, L).
