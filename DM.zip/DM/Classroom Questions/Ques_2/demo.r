library(arules)
dataset=read.transactions("1000-out1.csv",sep=",",rm.duplicate=TRUE)
dataset
summary(dataset)
# Adjust plot margins
# Open a new plotting window with specific dimensions
windows(width = 10, height = 6)  # Adjust width and height as needed

# Generate item frequency plot
itemFrequencyPlot(dataset, topN = 10)

rules=apriori(data=dataset,parameter=list(support=0.005,confidence=0.6))

rules

inspect(rules[1:100])

inspect(sort(rules,by="confidence")[1:20])
