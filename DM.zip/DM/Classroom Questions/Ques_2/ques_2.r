install.packages("arules")
# Load required packages
library(arules)

# Function to run Apriori algorithm and print rules
run_apriori <- function(data, min_support, min_confidence) {
  # Remove duplicates
  data <- unique(data)
  
  # Run Apriori algorithm
  rules <- apriori(data, parameter = list(support = min_support, confidence = min_confidence))
  
  # Print frequent itemsets
  print(summary(rules))
  
  # Print association rules
  print(head(sort(rules, by = "lift"), n = 10))
}

# Load datasets
data_1000 <- read.transactions("1000-out1.csv", sep = ",", format = "basket")
data_5000 <- read.transactions("5000-out1.csv", sep = ",", format = "basket")
data_market_basket <- read.transactions("Market_Basket.csv", sep = ",", format = "basket")

# Set thresholds
min_support_1 <- 0.5
min_confidence_1 <- 0.75

min_support_2 <- 0.6
min_confidence_2 <- 0.6

# Run Apriori for dataset 1000 with thresholds 1
cat("Dataset: 1000\n")
cat("Thresholds: Support =", min_support_1, "Confidence =", min_confidence_1, "\n")
run_apriori(data_1000, min_support_1, min_confidence_1)

# Run Apriori for dataset 1000 with thresholds 2
cat("\nThresholds: Support =", min_support_2, "Confidence =", min_confidence_2, "\n")
run_apriori(data_1000, min_support_2, min_confidence_2)

# Run Apriori for dataset 5000 with thresholds 1
cat("\nDataset: 5000\n")
cat("Thresholds: Support =", min_support_1, "Confidence =", min_confidence_1, "\n")
run_apriori(data_5000, min_support_1, min_confidence_1)

# Run Apriori for dataset 5000 with thresholds 2
cat("\nThresholds: Support =", min_support_2, "Confidence =", min_confidence_2, "\n")
run_apriori(data_5000, min_support_2, min_confidence_2)

# Run Apriori for Market Basket dataset with thresholds 1
cat("\nDataset: Market Basket\n")
cat("Thresholds: Support =", min_support_1, "Confidence =", min_confidence_1, "\n")
run_apriori(data_market_basket, min_support_1, min_confidence_1)

# Run Apriori for Market Basket dataset with thresholds 2
cat("\nThresholds: Support =", min_support_2, "Confidence =", min_confidence_2, "\n")
run_apriori(data_market_basket, min_support_2, min_confidence_2)

