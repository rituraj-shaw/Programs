library(fpc)
data(iris)
iris2 <- iris[-5]
iris2

ds <- dbscan(iris2,eps=0.45,MinPts=5)
ds

str(ds)
ds$cluster
table(ds$cluster,iris$Species)
x11()
plot(ds,iris2[c(1,4)])
plot(ds,iris2)
