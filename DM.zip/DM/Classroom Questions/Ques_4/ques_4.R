library (ggplot2)
data(iris)
iris2<-iris
iris2$Species<-NULL #removing dependent variable
str(iris2)
km<-kmeans(iris2,3) #forms '3' clusters
km$centers # centers of all clusters
km$cluster #cluster of every record
km$iter #no. of clustering iterations
km$withinss #sse of each cluster
iris2$cluster<-factor(km$cluster) # new column for cluster no.
iris2
I<-iris2[c(1,2,5)] # taking 1st & 2nd columns to plot and 5th for clustering
I
centers<-data.frame(cluster=factor(1:3),km$centers) #collecting clusters' centers into a factor
centers

#graph plotted b/w x-y
x11()
ggplot(data=I,aes(x=Sepal.Length,y=Sepal.Width,color=cluster,shape=cluster))+
  geom_point(alpha=0.2)+ #alpha is the width of points
  geom_point(data=centers,aes(x=Sepal.Length,y=Sepal.Width),size=3,stroke=2)
#size is the size of center points of each cluster
