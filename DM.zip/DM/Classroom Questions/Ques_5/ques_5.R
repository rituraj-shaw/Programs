# Read data from employee.txt
employee_data <- read.table("employee.txt", header=TRUE)

# Define rules
rules <- list(
  age_range = function(data) sum(data$Age < 15 | data$Age > 65),
  salary_grade = function(data) sum(data$Salary < 25000 & data$Grade != "B"),
  increment_salary = function(data) sum(data$Increment >= data$Salary),
  valid_department = function(data) sum(!(data$Department %in% c("Manufacturing", "Sales")))
)

# Apply rules to the data
rule_results <- sapply(rules, function(rule) rule(employee_data))

# Summarize results
print(rule_results)

# Plot results
x11()
barplot(rule_results, main="Rule Violations", xlab="Rules", ylab="Frequency", col="skyblue")
