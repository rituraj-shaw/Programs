# Load the cars dataset
data <- cars

# Display structure of the dataset
str(data)

# Compute arithmetic mean, geometric mean, harmonic mean, and median of speed column
arithmetic_mean_speed <- mean(data$speed)
geometric_mean_speed <- exp(mean(log(data$speed)))
harmonic_mean_speed <- 1/mean(1/data$speed)
median_speed <- median(data$speed)

# Compute arithmetic mean, geometric mean, harmonic mean, and median of dist column
arithmetic_mean_dist <- mean(data$dist)
geometric_mean_dist <- exp(mean(log(data$dist)))
harmonic_mean_dist <- 1/mean(1/data$dist)
median_dist <- median(data$dist)

# Display the results
cat("Arithmetic mean of speed:", arithmetic_mean_speed, "\n")
cat("Geometric mean of speed:", geometric_mean_speed, "\n")
cat("Harmonic mean of speed:", harmonic_mean_speed, "\n")
cat("Median of speed:", median_speed, "\n")

cat("Arithmetic mean of dist:", arithmetic_mean_dist, "\n")
cat("Geometric mean of dist:", geometric_mean_dist, "\n")
cat("Harmonic mean of dist:", harmonic_mean_dist, "\n")
cat("Median of dist:", median_dist, "\n")

# Find unique values of dist column
unique_dist <- unique(data$dist)

# Display unique values of dist column
cat("Unique values of dist column:", unique_dist, "\n")

# Find the variance of both columns
var_speed <- var(data$speed)
var_dist <- var(data$dist)

# Display the variances
cat("Variance of speed column:", var_speed, "\n")
cat("Variance of dist column:", var_dist, "\n")

# Find the IQR of speed column
IQR_speed <- IQR(data$speed)

# Display the IQR of speed column
cat("Interquartile Range (IQR) of speed column:", IQR_speed, "\n")

# Create quartiles for dist column
quartiles_dist <- quantile(data$dist, probs = c(0.25, 0.5, 0.75))

# Display quartiles for dist column
cat("Quartiles for dist column:", quartiles_dist, "\n")

