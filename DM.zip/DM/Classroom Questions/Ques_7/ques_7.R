# Load the dataset
dirty_android1 <- read.csv("dirty_android1.csv")

# a) Identify the count of NA’s in the data frame
na_count <- sum(is.na(dirty_android1))
cat("Count of NAs in the data frame:", na_count, "\n")

# b) Calculate the number and percentage of observations that are complete
complete_obs_count <- sum(complete.cases(dirty_android1))
complete_obs_percentage <- (complete_obs_count / nrow(dirty_android1)) * 100
cat("Number of complete observations:", complete_obs_count, "\n")
cat("Percentage of complete observations:", complete_obs_percentage, "%\n")

# c) Find the position of NA values in LCOM3 column
na_positions_LCOM3 <- which(is.na(dirty_android1$LCOM3))
cat("Position of NA values in LCOM3 column:", na_positions_LCOM3, "\n")

# d) Report the mean values of each column
means <- colMeans(dirty_android1[, !names(dirty_android1) %in% "CHANGE"], na.rm = TRUE)
cat("Mean values of each column (excluding 'CHANGE'):\n")
print(means)

# e) Replace all empty rows with mean values of the column and report the mean values of each column
dirty_android1_imputed <- dirty_android1
for (col in names(dirty_android1_imputed)) {
  if (col != "CHANGE" && class(dirty_android1_imputed[[col]]) != "character") {
    dirty_android1_imputed[is.na(dirty_android1_imputed[, col]), col] <- means[col]
  }
}
means_imputed <- colMeans(dirty_android1_imputed[, !names(dirty_android1_imputed) %in% "CHANGE"])
cat("Mean values of each column after replacing NAs with column means (excluding 'CHANGE'):\n")
print(means_imputed)

# f) Read the dataset again in another data frame variable. Omit all the records with NA values.
clean_dirty_android1 <- na.omit(dirty_android1)
