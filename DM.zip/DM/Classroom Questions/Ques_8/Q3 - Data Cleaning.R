(person <- read.csv("C:/Users/aaumg/Files/Programming/R/Data Mining/unnamed.txt"))

person <- read.csv(
  file = "C:/Users/aaumg/Files/Programming/R/Data Mining/unnamed.txt"
  , header = FALSE
  , col.names = c("age","height") )

person

dat <- read.csv(
  file = "C:/Users/aaumg/Files/Programming/R/Data Mining/unnamed.txt"
  , header = FALSE
  , col.names = c("age","height")
  , stringsAsFactors=FALSE)
dat$height <- as.numeric(dat$height)

str(person)

dat

## Reading data with readLines
# Step 1. Reading data.
(txt <- readLines("C:/Users/aaumg/Files/Programming/R/Data Mining/daltons.txt"))

# Step 2. Selecting lines containing data.
# detect lines starting with a percentage sign..
I <- grepl("^%", txt)
# and throw them out
(dat <- txt[!I])

# Step 3. Split lines into separate fields.
(fieldList <- strsplit(dat, split = ","))

# Step 4. Standardize rows.
assignFields <- function(x){
  out <- character(3)
  # get names
  i <- grepl("[[:alpha:]]",x)
  out[1] <- x[i]
  # get birth date (if any)
  i <- which(as.numeric(x) < 1890)
  out[2] <- ifelse(length(i)>0, x[i], NA)
  # get death date (if any)
  i <- which(as.numeric(x) > 1890)
  out[3] <- ifelse(length(i)>0, x[i], NA)
  out
}

standardFields <- lapply(fieldList, assignFields)
standardFields

# Step 5. Transform to data.frame.
(M <- matrix(
  unlist(standardFields)
  , nrow=length(standardFields)
  , byrow=TRUE))

colnames(M) <- c("name","birth","death")
(daltons <- as.data.frame(M, stringsAsFactors=FALSE))

# Step 6. Normalize and coerce to correct types.
daltons$birth <- as.numeric(daltons$birth)
daltons$death <- as.numeric(daltons$death)
daltons

daltons = transform( daltons
                     , birth = as.numeric(birth)
                     , death = as.numeric(death)
)
daltons