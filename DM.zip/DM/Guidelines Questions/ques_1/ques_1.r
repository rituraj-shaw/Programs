# Step 1: Create the people.txt file
people_data <- "
Age  agegroup height status yearsmarried
21     adult   6.0   single    -1
2     child     3    married    0
18     adult   5.7   married   20
221   elderly   5    widowed   2
34     child   -7    married   3
"

writeLines(people_data, "people.txt")

# Step 2: Read data from the file
data <- read.table("people.txt", header = TRUE)

# Step 3: Define ruleset E
ruleset_E <- function(data) {
  violations <- c()
  for (i in 1:nrow(data)) {
    age <- data$Age[i]
    agegroup <- data$agegroup[i]
    status <- data$status[i]
    yearsmarried <- data$yearsmarried[i]
    
    if (!(age >= 0 && age <= 150)) {
      violations <- c(violations, paste("Age", age, "is not in the range 0-150."))
    }
    if (age <= yearsmarried) {
      violations <- c(violations, paste("Age", age, "is not greater than years married (", yearsmarried, ")."))
    }
    if (!(status %in% c("married", "single", "widowed"))) {
      violations <- c(violations, paste("Status '", status, "' is not valid."))
    }
    if (age < 18 && agegroup != "child") {
      violations <- c(violations, paste("Age", age, "should be in the 'child' age group."))
    } else if (age >= 18 && age < 65 && agegroup != "adult") {
      violations <- c(violations, paste("Age", age, "should be in the 'adult' age group."))
    } else if (age >= 65 && agegroup != "elderly") {
      violations <- c(violations, paste("Age", age, "should be in the 'elderly' age group."))
    }
  }
  return(violations)
}

# Step 4: Check violations
violations <- ruleset_E(data)

# Step 5: Summarize results
if (length(violations) > 0) {
  cat("Ruleset E violations:\n")
  cat(violations, sep = "\n")
} else {
  cat("No violations found according to ruleset E.\n")
}

# Step 6: Visualize results
library(ggplot2)

# Count violations for each rule
rule_counts <- table(unlist(strsplit(violations, ":")))
# Create a bar plot
bar_data <- data.frame(rule = names(rule_counts), count = as.numeric(rule_counts))

# Plot
x11()
ggplot(bar_data, aes(x = rule, y = count)) +
  geom_bar(stat = "identity", fill = "skyblue", color = "black") +
  labs(title = "Violations Count for Each Rule", x = "Rule", y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Count violations for each age group
agegroup_counts <- table(data$agegroup)

# Create a bar plot
bar_data_agegroup <- data.frame(agegroup = names(agegroup_counts), count = as.numeric(agegroup_counts))

# Plot
x11()
ggplot(bar_data_agegroup, aes(x = agegroup, y = count)) +
  geom_bar(stat = "identity", fill = "lightgreen", color = "black") +
  labs(title = "Violations Count by Age Group", x = "Age Group", y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

