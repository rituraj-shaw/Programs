# Load required libraries
library(dplyr)
library(editrules)

# Load the dataset
dirty_iris <- read.csv("iris_dirty.csv")

# i) Calculate the number and percentage of observations that are complete
complete_obs <- sum(complete.cases(dirty_iris))
total_obs <- nrow(dirty_iris)
percentage_complete <- (complete_obs / total_obs) * 100
cat("Number of complete observations:", complete_obs, "\n")
cat("Percentage of complete observations:", percentage_complete, "%\n")

# ii) Replace all the special values in data with NA
dirty_iris[dirty_iris == "?"] <- NA

# iii) Define rules in a separate text file and read them
# (Assuming rules are defined in a text file named "iris_rules.txt")
rules <- editfile("iris_rules.txt")
print(rules)

# iv) Determine how often each rule is broken
violations <- violatedEdits(rules, dirty_iris)
summary(violations)
x11()
plot(violations)

# v) Find outliers in sepal length using boxplot and boxplot.stats
x11()
boxplot(dirty_iris$Sepal.Length, main="Boxplot of Sepal Length")
outliers <- boxplot.stats(dirty_iris$Sepal.Length)$out
