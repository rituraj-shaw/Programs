# Load the Iris dataset
iris_data <- datasets::iris

# Check if all columns are numeric (excluding Species column)
numeric_columns <- iris_data[, sapply(iris_data, is.numeric)]
if (!is.matrix(numeric_columns)) {
  print("Not all columns are numeric. Converting...")
  numeric_columns <- apply(numeric_columns, 2, as.numeric)
}

# Check if attributes are standardized
standardized <- sapply(numeric_columns, function(x) {
  mean(x, na.rm = TRUE) == 0 && sd(x, na.rm = TRUE) == 1
})

# Check if all numeric attributes are standardized
if(all(standardized)) {
  print("All numeric attributes are standardized.")
} else {
  print("Not all numeric attributes are standardized. Standardizing...")
  # Standardize the numeric attributes
  numeric_columns <- scale(numeric_columns)
}

# Combine standardized numeric columns with non-numeric columns
iris_data_standardized <- cbind(numeric_columns, iris_data[, !sapply(iris_data, is.numeric)])

# Check the standardized attributes
summary(iris_data_standardized)
