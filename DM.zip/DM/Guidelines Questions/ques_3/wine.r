# Load the data from UCI Machine Learning Repository
wine_data <- read.csv("https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data", header = FALSE)

# Check if attributes are standardized
standardized <- apply(wine_data, 2, function(x) {
  mean(x) == 0 && sd(x) == 1
})

# Check if all attributes are standardized
if(all(standardized)) {
  print("All attributes are standardized.")
} else {
  print("Not all attributes are standardized. Standardizing...")
  # Standardize the attributes
  wine_data <- scale(wine_data)
}

# Check the standardized attributes
summary(wine_data)

