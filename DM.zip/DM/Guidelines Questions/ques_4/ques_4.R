# Load necessary library
library(arules)

# Function to run Apriori algorithm and evaluate patterns
run_apriori <- function(dataset, min_support, min_confidence) {
  # Load dataset
  data <- read.transactions(dataset, sep = ",", format = "basket", rm.duplicates = TRUE)
  
  # Run Apriori algorithm
  rules <- apriori(data, parameter = list(support = min_support, confidence = min_confidence))
  
  # Print frequent itemsets and association rules
  cat("\nFrequent Itemsets:\n")
  inspect(head(sort(rules, by = "support"), 10))
  
  cat("\nAssociation Rules:\n")
  inspect(head(sort(rules, by = "confidence"), 10))
  
  # Evaluate correctness of obtained patterns
  # Here we can use different evaluation measures based on your requirements
  # For example, we can compute the lift of association rules
  
  lift <- interestMeasure(rules, measure = "lift")
  
  # Print lift values
  cat("\nLift values:\n")
  print(head(lift))
}

# Dataset 1
dataset1 <- "1000-out1.csv"
cat("Dataset 1:\n")
run_apriori(dataset1, min_support = 0.5, min_confidence = 0.75)

# Dataset 2
dataset2 <- "5000-out1.csv"
cat("\nDataset 2:\n")
run_apriori(dataset2, min_support = 0.6, min_confidence = 0.6)
