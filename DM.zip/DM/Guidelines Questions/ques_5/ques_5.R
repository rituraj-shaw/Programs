#Confusion matrix are hidden with comments
#If want you can use
# Load necessary libraries
library(e1071)  # For Naive Bayes
library(class)  # For k-Nearest Neighbors
library(rpart)  # For Decision Trees
library(caret)  # For data splitting and scaling

# Load dataset (for example, iris dataset)
data(iris)

# 5.1 Data Splitting
# a) Training set = 75%, Test set = 25%
set.seed(123)  # for reproducibility
train_index <- createDataPartition(iris$Species, p = 0.75, list = FALSE)
train_data <- iris[train_index, ]
test_data <- iris[-train_index, ]

# b) Training set = 66.6%, Test set = 33.3%
set.seed(123)  # for reproducibility
train_index_2 <- createDataPartition(iris$Species, p = 2/3, list = FALSE)
train_data_2 <- iris[train_index_2, ]
test_data_2 <- iris[-train_index_2, ]

# 5.2 Data Splitting Methods
# ii) Random subsampling
# We will randomly sample 75% of the data for training and 25% for testing
set.seed(123)  # for reproducibility
random_index <- sample(1:nrow(iris), size = round(0.75 * nrow(iris)))
train_data_random <- iris[random_index, ]
test_data_random <- iris[-random_index, ]

# iii) Cross-Validation
# We'll use 5-fold cross-validation
set.seed(123)  # for reproducibility
train_control <- trainControl(method = "cv", number = 5)
cv_nb_model <- train(Species ~ ., data = iris, method = "nb", trControl = train_control)
cv_knn_model <- train(Species ~ ., data = iris, method = "knn", trControl = train_control, tuneGrid = data.frame(k = 3))
cv_dt_model <- train(Species ~ ., data = iris, method = "rpart", trControl = train_control)

# 5.3 Data Scaling
# Scaling the data to standard format
scaled_iris <- scale(iris[, -5])  # Exclude the target variable (Species)

# Now, build classifiers for Naive Bayes, k-Nearest Neighbors, and Decision Trees
# Using the training data obtained from different methods

# Naive Bayes
nb_model <- naiveBayes(Species ~ ., data = train_data)

# k-Nearest Neighbors
knn_model <- knn(train_data[, -5], test_data[, -5], train_data$Species, k = 3)

# Decision Trees
dt_model <- rpart(Species ~ ., data = train_data, method = "class")

# Output for 5.1 Data Splitting
cat("5.1 Data Splitting:\n")

# a) Training set = 75%, Test set = 25%
cat("a) Training set = 75%, Test set = 25%\n")
# Accuracy for Naive Bayes
nb_pred_a <- predict(nb_model, test_data)
nb_accuracy_a <- mean(nb_pred_a == test_data$Species)
cat("Accuracy for Naive Bayes:", nb_accuracy_a, "\n")
#confusionMatrix(nb_pred_a, test_data$Species)

# Accuracy for k-Nearest Neighbors
knn_pred_a <- knn(train_data[, -5], test_data[, -5], train_data$Species, k = 3)
knn_accuracy_a <- mean(knn_pred_a == test_data$Species)
cat("Accuracy for k-Nearest Neighbors:", knn_accuracy_a, "\n")
#confusionMatrix(knn_pred_a, test_data$Species)

# Accuracy for Decision Trees
dt_pred_a <- predict(dt_model, test_data, type = "class")
dt_accuracy_a <- mean(dt_pred_a == test_data$Species)
cat("Accuracy for Decision Trees:", dt_accuracy_a, "\n")
#confusionMatrix(dt_pred_a, test_data$Species)

# b) Training set = 66.6%, Test set = 33.3%
cat("\nb) Training set = 66.6%, Test set = 33.3%\n")
# Accuracy for Naive Bayes
nb_pred_b <- predict(nb_model, test_data_2)
nb_accuracy_b <- mean(nb_pred_b == test_data_2$Species)
cat("Accuracy for Naive Bayes:", nb_accuracy_b, "\n")
#confusionMatrix(nb_pred_b, test_data_2$Species)

# Accuracy for k-Nearest Neighbors
knn_pred_b <- knn(train_data_2[, -5], test_data_2[, -5], train_data_2$Species, k = 3)
knn_accuracy_b <- mean(knn_pred_b == test_data_2$Species)
cat("Accuracy for k-Nearest Neighbors:", knn_accuracy_b, "\n")
#confusionMatrix(knn_pred_b, test_data_2$Species)

# Accuracy for Decision Trees
dt_pred_b <- predict(dt_model, test_data_2, type = "class")
dt_accuracy_b <- mean(dt_pred_b == test_data_2$Species)
cat("Accuracy for Decision Trees:", dt_accuracy_b, "\n")
#confusionMatrix(dt_pred_b, test_data_2$Species)

# Output for 5.2 Data Splitting Methods
cat("\n5.2 Data Splitting Methods:\n")

# ii) Random subsampling
cat("ii) Random subsampling\n")
# Accuracy for Naive Bayes
nb_pred_random <- predict(nb_model, test_data_random)
nb_accuracy_random <- mean(nb_pred_random == test_data_random$Species)
cat("Accuracy for Naive Bayes:", nb_accuracy_random, "\n")
#confusionMatrix(nb_pred_random, test_data_random$Species)

# Accuracy for k-Nearest Neighbors
knn_pred_random <- knn(train_data_random[, -5], test_data_random[, -5], train_data_random$Species, k = 3)
knn_accuracy_random <- mean(knn_pred_random == test_data_random$Species)
cat("Accuracy for k-Nearest Neighbors:", knn_accuracy_random, "\n")
#confusionMatrix(knn_pred_random, test_data_random$Species)

# Accuracy for Decision Trees
dt_pred_random <- predict(dt_model, test_data_random, type = "class")
dt_accuracy_random <- mean(dt_pred_random == test_data_random$Species)
cat("Accuracy for Decision Trees:", dt_accuracy_random, "\n")
#confusionMatrix(dt_pred_random, test_data_random$Species)

# iii) Cross-Validation
cat("\niii) Cross-Validation\n")
# Accuracy for Naive Bayes
cv_nb_pred <- predict(cv_model, newdata = iris)
cv_nb_accuracy <- mean(cv_nb_pred == iris$Species)
cat("Accuracy for Naive Bayes:", cv_nb_accuracy, "\n")
#confusionMatrix(cv_nb_pred, iris$Species)

# Accuracy for k-Nearest Neighbors
cat("Accuracy for k-Nearest Neighbors:", cv_knn_model$results$Accuracy, "\n")

# Accuracy for Decision Trees
cat("Accuracy for Decision Trees:", cv_dt_model$results$Accuracy, "\n")


# For k-Nearest Neighbors and Decision Trees, you would need to train models using cross-validation
# as it's not directly applicable like Naive Bayes

# Since we didn't train new models after scaling the data, the accuracy would remain the same for each model.
# However, you can apply scaling to the data before training the models if needed.
