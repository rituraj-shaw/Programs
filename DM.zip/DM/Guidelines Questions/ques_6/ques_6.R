# Load necessary libraries
library(cluster)
library(factoextra)
library(dbscan)

# Generate sample data
set.seed(123)
data <- matrix(rnorm(300, mean = 10, sd = 3), ncol = 3)

# Simple Kmeans clustering
kmeans_result <- kmeans(data, centers = 3, nstart = 25)
kmeans_clusters <- kmeans_result$cluster
kmeans_clusters

# DBScan clustering
dbscan_result <- dbscan(data, eps = 0.5, minPts = 5)
dbscan_clusters <- dbscan_result$cluster[dbscan_result$cluster != 0]
dbscan_clusters

# Hierarchical clustering
hierarchical_result <- hclust(dist(data), method = "ward.D2")
hierarchical_clusters <- cutree(hierarchical_result, k = 3)
hierarchical_clusters

# Compute silhouette scores
kmeans_silhouette <- silhouette(kmeans_clusters, dist(data))
dbscan_silhouette <- silhouette(dbscan_clusters, dist(data))
hierarchical_silhouette <- silhouette(hierarchical_clusters, dist(data))

# Print silhouette scores
cat("Kmeans Silhouette Score:", mean(kmeans_silhouette[, "sil_width"]), "\n")
cat("DBScan Silhouette Score:", mean(kmeans_silhouette[, "sil_width"]),"\n")
cat("Hierarchical Silhouette Score:", mean(hierarchical_silhouette[, "sil_width"]), "\n")
